from django.contrib import admin
from djapp import models
# Register your models here.
admin.site.register(models.Worker)